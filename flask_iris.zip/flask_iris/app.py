from flask import Flask, render_template, request
import pickle
import numpy as np

model = pickle.load(open('model\iris.pkl', 'rb'))

app = Flask(__name__)



@app.route('/')
def man():
    return render_template('home.html')


@app.route('/', methods=['POST'])
def home():
	if request.method == 'POST':
		data1 = float(request.form['sepal length'])
		data2 = float(request.form['sepal width'])
		data3 = float(request.form['petal length'])
		data4 = float(request.form['petal width'])
		arr = np.array([[data1, data2, data3, data4]])
		pred = model.predict(arr)
		return render_template('after.html', data=pred)


if __name__ == "__main__":
    app.run(host='127.0.0.1',port=8000,debug=True)

